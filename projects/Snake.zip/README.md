# Snake Game Project

Hi and thanks for downloading my Java Swing Snake Game.

## Usage

To play the game:

Make sure to have at least OpenJDK 21 installed.

1. Do "Extract All" to a desired location
2. Double click on the 'run_snake.vbs'
